# maze-solver
An implementation of A* algorithm, to find the shortest path inside a maze (with animation of pacman).
# install
start a http server
example : php -S 127.0.0.1:5000
link to 127.0.0.1:5000
